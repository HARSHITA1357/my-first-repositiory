<!DOCTYPE html>
<html>
<head>
    <title>Image Uploader</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            background-color: #f2f2f2;
            color: #333;
        }

        .file-upload {
            margin-bottom: 20px;
        }

        /* .file-upload input[type="file"] {
            display: none;
        } */

        .file-upload label {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        .file-upload label:hover {
            background-color: #0056b3;
        }

        .image-list {
            list-style: none;
            padding: 0;
        }

        .image-list li {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
            padding: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
        }

        .image-list img {
            max-width: 100px;
            max-height: 100px;
        }

        .image-list form {
            margin-left: 10px;
        }

        .image-list button {
            padding: 5px 10px;
            background-color: #ff3b30;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .image-list button:hover {
            background-color: #d63028;
        }
    </style>
</head>
<body>
    <div class="container"style="margin-top: 73px;">
        <h1>Image Uploader</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('image.upload')); ?>" method="POST" enctype="multipart/form-data" class="file-upload">
            <?php echo csrf_field(); ?>
            <input type="file" name="images[]" id="file-upload" multiple required>
            <button type="submit">Upload</button>
        </form>

        <ul class="image-list">
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <img src="<?php echo e(asset('storage/images/' . $image->file_name)); ?>" alt="<?php echo e($image->name); ?>">
                    <form action="<?php echo e(route('image.delete', $image->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</body>
</html>
<?php /**PATH C:\xampps\htdocs\image-upload-app\resources\views/images/index.blade.php ENDPATH**/ ?>