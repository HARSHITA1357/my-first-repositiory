<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Image;

class ImageController extends Controller
{
    public function index()
    {
        $images = Image::all();
        return view('images.index', compact('images'));
    }

    public function upload(Request $request)
    {
        $request->validate([
            'images' => 'required|array',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        foreach ($request->file('images') as $image) {
            $imageName = time() . '_' . $image->getClientOriginalName();
            $image->storeAs('public/images', $imageName);
// dd($imageName);
            Image::create(['file_name' => $imageName]);
        }

        return redirect()->route('images.index')->with('success', 'Images uploaded successfully.');
    }

    public function delete($id)
    {
        $image = Image::find($id);
        if ($image) {
            // Delete the image file from storage
            $imagePath = storage_path('app/public/storage/images/' . $image->name);
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
            // Delete the image record from the database
            $image->delete();

            return redirect()->route('images.index')->with('success', 'Image deleted successfully.');
        }

        return redirect()->route('images.index')->with('error', 'Image not found.');
    }
}
