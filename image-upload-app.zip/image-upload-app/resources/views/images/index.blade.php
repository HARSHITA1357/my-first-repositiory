<!DOCTYPE html>
<html>
<head>
    <title>Image Uploader</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            background-color: #f2f2f2;
            color: #333;
        }

        .file-upload {
            margin-bottom: 20px;
        }

        /* .file-upload input[type="file"] {
            display: none;
        } */

        .file-upload label {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        .file-upload label:hover {
            background-color: #0056b3;
        }

        .image-list {
            list-style: none;
            padding: 0;
        }

        .image-list li {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
            padding: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
        }

        .image-list img {
            max-width: 100px;
            max-height: 100px;
        }

        .image-list form {
            margin-left: 10px;
        }

        .image-list button {
            padding: 5px 10px;
            background-color: #ff3b30;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .image-list button:hover {
            background-color: #d63028;
        }
    </style>
</head>
<body>
    <div class="container"style="margin-top: 73px;">
        <h1>Image Uploader</h1>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif

        <form action="{{ route('image.upload') }}" method="POST" enctype="multipart/form-data" class="file-upload">
            @csrf
            <input type="file" name="images[]" id="file-upload" multiple required>
            <button type="submit">Upload</button>
        </form>

        <ul class="image-list">
            @foreach($images as $image)
                <li>
                    <img src="{{ asset('storage/images/' . $image->file_name) }}" alt="{{ $image->name }}">
                    <form action="{{ route('image.delete', $image->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </li>
            @endforeach
        </ul>
    </div>
</body>
</html>
